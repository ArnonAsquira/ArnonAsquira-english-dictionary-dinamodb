"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PORT = void 0;
exports.PORT = process.env.PORT || 3000;
//# sourceMappingURL=enviorment-varibales.js.map